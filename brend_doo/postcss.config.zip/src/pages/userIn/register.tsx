import { useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';

const Register = () => {
    const [showPassword, setShowPassword] = useState(false);
    const [variant, setvariant] = useState<1 | 2>(1);

    const togglePasswordVisibility = () => {
        setShowPassword((prev) => !prev);
    };

    // Validation Schema using Yup
    const validationSchema = Yup.object({
        name: Yup.string().required('Ad daxil edin'),
        phone: Yup.string()
            .matches(/^\d{10}$/, 'Telefon nömrəsi düzgün deyil')
            .required('Telefon nömrəsi daxil edin'),
        email: Yup.string()
            .email('Email düzgün deyil')
            .required('Email daxil edin'),
        password: Yup.string()
            .min(8, 'Şifrə ən az 8 simvoldan ibarət olmalıdır')
            .required('Şifrə daxil edin'),
        acceptTerms: Yup.boolean()
            .oneOf([true], 'İstifadəçi qaydaları ilə razı olmalısınız')
            .required('İstifadəçi qaydaları ilə razı olmalısınız'),
    });
    const navigate = useNavigate();
    async function handleRegister(values: {
        name: string;
        phone: string;
        email: string;
        password: string;
    }) {
        await axios
            .post('https://brendo.avtoicare.az/api/register', values)
            .then((response) => {
                if (response.status === 201) {
                    localStorage.setItem('register-token', response.data.token);
                    // toast.success('registred sucsesfulley');
                    setvariant(2);
                }
            })
            .catch((error) => {
                if (error.response && error.response.status === 422) {
                    toast.error(`user is alredy exsist `);
                }
            });
        // if (response.status === 201) {
        //     // toast.success('registred sucsesfulley');
        //     setvariant(2);
        // }
        // if (response.status === 402) {
        //     toast.success('registred eror 402');
        //     setvariant(2);
        // }
    }
    return (
        <div className="flex overflow-hidden flex-col bg-white">
            <div className="flex relative flex-col w-full h-[100vh] max-md:max-w-full justify-center items-center px-[40px] max-sm:px-4">
                <img
                    loading="lazy"
                    srcSet="https://cdn.builder.io/api/v1/image/assets/TEMP/9f57b393c120b19ab9db1e7a4aa3dc11e48fdaa0526b775a0fd5a02c9292e45c?placeholderIfAbsent=true&apiKey=2d5d82cf417847beb8cd2fbbc5e3c099"
                    className="object-cover absolute inset-0 size-full"
                />
                <div
                    onClick={() => navigate(-1)}
                    className="rounded-full bg-white lg:w-[56px] lg:h-[56px] w-[35px] h-[35px] bg-opacity-60 z-50 absolute top-5 left-5 cursor-pointer"
                >
                    <img
                        loading="lazy"
                        src="https://cdn.builder.io/api/v1/image/assets/TEMP/d1d01662ce302f4f64e209cc8ecd0540b6f0e5fb3d4ccd79eead1b316a272d11?placeholderIfAbsent=true&apiKey=2d5d82cf417847beb8cd2fbbc5e3c099"
                        className="object-contain w-14 aspect-square rounded-full"
                    />
                </div>

                {variant === 1 && (
                    <div className="flex  overflow-hidden relative flex-col justify-center self-center lg:px-16  lg:py-6 p-[10px] mb-0 max-w-full rounded-3xl bg-white bg-opacity-20 w-[560px] ">
                        <div className="flex flex-col max-md:max-w-full">
                            <div className="flex flex-col items-center self-center text-center">
                                <div className="text-3xl font-bold text-white">
                                    Qeydiyyatdan Keçin
                                </div>
                                <div className="mt-3 text-base text-white text-opacity-80">
                                    Hesab yaratmaq üçün məlumatlarınızı daxil
                                    edin.
                                </div>
                            </div>

                            {/* Formik Form */}
                            <Formik
                                initialValues={{
                                    name: '',
                                    phone: '',
                                    email: '',
                                    password: '',
                                }}
                                validationSchema={validationSchema}
                                onSubmit={async (values) => {
                                    console.log(values);
                                    handleRegister({
                                        name: values.name,
                                        password: values.password,
                                        email: values.email,
                                        phone: values.phone,
                                    });
                                }}
                            >
                                {({}) => (
                                    <Form className="flex flex-col items-center mt-4 w-full max-md:max-w-full">
                                        <div className="flex gap-3 items-center text-base font-semibold text-center text-white">
                                            <img
                                                loading="lazy"
                                                src="https://cdn.builder.io/api/v1/image/assets/TEMP/d3022fd65942a1f100f9b4b03e803efbd39acdf620aeebe49dd8d33234dd171c?placeholderIfAbsent=true&apiKey=2d5d82cf417847beb8cd2fbbc5e3c099"
                                                className="object-contain shrink-0 self-stretch my-auto w-12 aspect-square rounded-full"
                                            />
                                            <div className="self-stretch my-auto">
                                                Google ilə davam et
                                            </div>
                                        </div>
                                        <div className="flex lg:gap-10 gap-5 items-center mt-4 text-xs text-center text-white w-full mb-4">
                                            <div className="shrink-0 self-stretch my-auto h-px border border-solid border-white border-opacity-20 w-[35%]" />
                                            <div className="self-stretch my-auto text-nowrap">
                                                Və ya
                                            </div>
                                            <div className="shrink-0 self-stretch my-auto h-px border border-solid border-white border-opacity-20 w-[35%]" />
                                        </div>
                                        <div className="flex flex-col w-full max-md:max-w-full">
                                            <Field
                                                name="name"
                                                className="overflow-hidden px-5 py-5 w-full h-[56px] text-base whitespace-nowrap bg-white border border-solid border-black border-opacity-10 rounded-[100px] text-black text-opacity-60"
                                                placeholder="Ad - Soyad"
                                            />
                                            <ErrorMessage
                                                name="name"
                                                component="div"
                                                className="text-red-500 text-xs mt-1"
                                            />

                                            <div className="flex  overflow-hidden px-5  w-full h-[56px] text-base whitespace-nowrap bg-white border border-solid border-black border-opacity-10 rounded-[100px] text-black text-opacity-60 mt-3">
                                                <span className="text-black text-opacity-60 flex justify-center items-center">
                                                    +994
                                                </span>
                                                <Field
                                                    name="phone"
                                                    className="outline-none bg-transparent ml-1 w-full h-[56px]"
                                                    placeholder="XX XXX XX XX"
                                                />
                                            </div>
                                            <ErrorMessage
                                                name="phone"
                                                component="div"
                                                className="text-red-500 text-xs mt-1"
                                            />

                                            <Field
                                                name="email"
                                                className="overflow-hidden px-5 py-5 w-full h-[56px] text-base whitespace-nowrap bg-white border border-solid border-black border-opacity-10 rounded-[100px] text-black text-opacity-60 mt-3"
                                                placeholder="Email"
                                            />
                                            <ErrorMessage
                                                name="email"
                                                component="div"
                                                className="text-red-500 text-xs mt-1"
                                            />

                                            <div className="flex overflow-hidden gap-5 justify-between px-5  w-full h-[56px] text-base whitespace-nowrap bg-white border border-solid border-black border-opacity-10 rounded-[100px] text-black text-opacity-60 mt-3">
                                                <Field
                                                    type={
                                                        showPassword
                                                            ? 'text'
                                                            : 'password'
                                                    }
                                                    name="password"
                                                    placeholder="Şifrə"
                                                    className="outline-none bg-transparent w-full h-[56px]"
                                                />
                                                <img
                                                    loading="lazy"
                                                    onClick={
                                                        togglePasswordVisibility
                                                    }
                                                    src={
                                                        showPassword
                                                            ? 'https://cdn.builder.io/api/v1/image/assets/TEMP/cc75299a447e1f2b81cfaeb2821950c885d45d255e50ae73ad2684fcd9aa2110?placeholderIfAbsent=true&apiKey=2d5d82cf417847beb8cd2fbbc5e3c099'
                                                            : '/svg/closedaye.svg'
                                                    }
                                                    className="object-contain shrink-0 w-6 aspect-square cursor-pointer"
                                                    alt="Toggle Password Visibility"
                                                />
                                            </div>
                                            <ErrorMessage
                                                name="password"
                                                component="div"
                                                className="text-red-500 text-xs mt-1"
                                            />
                                            <div className="flex items-center mt-4">
                                                <Field
                                                    type="checkbox"
                                                    name="acceptTerms"
                                                    className="mr-2 w-[14px] h-[14px]"
                                                />
                                                <label className="text-sm font-semibold text-white ">
                                                    İstifadəçi qaydaları ilə
                                                    razıyam
                                                </label>
                                            </div>
                                            <ErrorMessage
                                                name="acceptTerms"
                                                component="div"
                                                className="text-red-500 text-xs mt-1"
                                            />

                                            <div className="gap-2.5 self-stretch px-10 py-4 lg:mt-7 mt-4 w-full text-base font-medium text-black border border-solid bg-slate-300 border-slate-300 rounded-[100px] max-md:px-5 max-md:max-w-full">
                                                <button
                                                    type="submit"
                                                    className="w-full cursor-pointer"
                                                >
                                                    Qeydiyyatdan Keç
                                                </button>
                                            </div>
                                        </div>
                                    </Form>
                                )}
                            </Formik>
                        </div>

                        <div
                            className="mt-4 cursor-pointer text-base font-semibold text-center text-white text-opacity-80 lg:mt-4  max-md:max-w-full"
                            onClick={() => {
                                navigate('/user/login');
                            }}
                        >
                            <span>Hesabınız var?</span> Daxil olun
                        </div>
                    </div>
                )}
                {variant === 2 && (
                    <div className="bg-white z-50 rounded-[20px] bg-opacity-25  px-[50px] py-[60px] flex flex-col justify-center items-center">
                        <h5 className="text-[32px] mb-3 text-white font-semibold leading-10">
                            Elektron adresini yoxla!
                        </h5>
                        <p className="text-[16px] text-white mb-[40px] max-w-[460px] font-normal text-center">
                            Sizə ilahanazarova77@gmail.com ünvanına altı rəqəmli
                            təsdiq kodu göndərdik. E-poçt ünvanınızı təsdiqləmək
                            üçün onu aşağıya daxil edin.
                        </p>
                        <Formik
                            initialValues={{ code: '' }}
                            validationSchema={Yup.object({
                                code: Yup.string()
                                    .length(6, 'Kod 6 rəqəmli olmalıdır')
                                    .required('Kod daxil edin'),
                            })}
                            onSubmit={(values) => {
                                const token =
                                    localStorage.getItem('register-token');
                                console.log(values);
                                axios
                                    .post(
                                        'https://brendo.avtoicare.az/api/verifyEmail',
                                        {
                                            verification_code: +values,
                                            verification_token: token,
                                        }
                                    )
                                    .then(() => {
                                        toast.success('register sucsesfylly');
                                        navigate('/user/login');
                                    })
                                    .catch((error) => {
                                        console.log('error', error);
                                        toast.error('error');
                                    });
                                // Handle code verification
                            }}
                        >
                            {({ handleSubmit }) => (
                                <Form
                                    onSubmit={handleSubmit}
                                    className="w-full"
                                >
                                    <Field
                                        placeholder="6 rəqəmli kod"
                                        className="overflow-hidden px-5 py-5 w-full h-[56px] text-base whitespace-nowrap bg-white border border-solid border-black border-opacity-10 rounded-[100px] text-black text-opacity-60"
                                        type="text"
                                        name="code"
                                    />
                                    <ErrorMessage
                                        name="code"
                                        component="div"
                                        className="text-red-500 text-xs mt-1"
                                    />
                                    <button
                                        type="submit"
                                        className="gap-2.5 self-stretch px-10 py-4 lg:mt-7 mt-4 w-full text-base font-medium text-black border border-solid bg-[#B1C7E4] border-[#B1C7E4] rounded-[100px] max-md:px-5 max-md:max-w-full"
                                    >
                                        Təsdiq et
                                    </button>
                                </Form>
                            )}
                        </Formik>
                        <button className="mt-4 cursor-pointer text-base font-semibold text-center text-white text-opacity-80 lg:mt-4  max-md:max-w-full">
                            Kodu yenidən göndər
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Register;
